AutoHotkey 1.1.37.02: GPL-2.0-or-later. Corresponding source and license included.
