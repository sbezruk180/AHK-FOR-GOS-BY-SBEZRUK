@echo off
cd /d "%~dp0"
start "" "%~dp0runtime\AutoHotkeyA32.exe" /CP1251 "%~dp0AHK_FOR_GOS_BY_SBEZRUK.ahk"
